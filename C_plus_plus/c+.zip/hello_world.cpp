// Your First C++ Program

#include <iostream>

using namespace std; // :-)

int main() {
    std::cout << "Hello World!";
    return 0;
}